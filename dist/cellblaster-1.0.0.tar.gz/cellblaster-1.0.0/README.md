# CellBLASTer

CellBLASTer is a plant single-cell RNA-seq cell-type annotation tool based on
cross-species orthogroups and symbolic expression matching.

## Installation from source

```bash
python -m pip install .
```

For editable development installation:

```bash
python -m pip install -e .
```

## Python API

```python
import CellBLASTer

annotator = CellBLASTer.CellBlaster(
    database_type="Dicot",
    organ="Root",
    symbols=["SRP169576"],
    output_path="./Output",
    query="./SRP182008.h5ad",
    query_symbol="SRP182008",
    filter_keywords=CellBLASTer.DEFAULT_NONCODING_RNA_KEYWORDS,
    n_jobs=30,
)

results = annotator.Annotation()
print(results)
```

The class can also be imported directly:

```python
from CellBLASTer import CellBlaster
```

## Command-line interface

After installation, all three commands below are supported:

```bash
cellblaster --help
python -m CellBLASTer --help
python CellBLASTer/CellBlaster.py --help
```

Example:

```bash
cellblaster \
    -t Dicot \
    -p Root \
    -s SRP169576 \
    -o ./Output \
    -q ./SRP182008.h5ad \
    -qs SRP182008 \
    --n-jobs 30
```

Optional user-defined reference dataset:

```bash
cellblaster \
    -t Dicot \
    -p Root \
    -s SRP169576 \
    -o ./Output \
    -q ./SRP182008.h5ad \
    -qs SRP182008 \
    --reference-adata ./MyReference.h5ad \
    --reference-symbol MyReference
```

Both the query h5ad and an optional reference h5ad must contain a `Celltype`
column in `adata.obs`. Cell and gene identifiers must be unique.
